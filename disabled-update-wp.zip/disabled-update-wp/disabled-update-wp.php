<?php
/**
 * Plugin Name: Personalizações do Painel WP
 * Plugin URI: https://uday.com.br
 * Description: Oculta a barra superior para usuários não administradores, mostra apenas login/logout para usuários comuns e mantém a barra para administradores @tribo.uday.com.br. Também remove o logo da tela de login, desativa atualizações automáticas e notificações do WordPress.
 * Version: 1.2
 * Author: Wesley Tibucio
 * Author URI: https://github.com/westibcar/plugins/
 * License: GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Impede execução direta
}

/**
 * Controla o conteúdo da admin bar.
 */
add_action('admin_bar_menu', 'customizar_admin_bar', 999);
function customizar_admin_bar($wp_admin_bar) {
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();

        // Admin com e-mail @tribo.uday.com.br mantém barra padrão
        if (in_array('administrator', $current_user->roles) && strpos($current_user->user_email, '@tribo.uday.com.br') !== false) {
            return;
        }
    }

    // Remove todos os itens da admin bar
    foreach ($wp_admin_bar->get_nodes() as $node) {
        $wp_admin_bar->remove_node($node->id);
    }

    // Adiciona botão de login/logout
    if (is_user_logged_in()) {
        $wp_admin_bar->add_node([
            'id'    => 'logout',
            'title' => 'Logout',
            'href'  => wp_logout_url(home_url())
        ]);
    } else {
        $wp_admin_bar->add_node([
            'id'    => 'login',
            'title' => 'Login',
            'href'  => wp_login_url()
        ]);
    }
}

/**
 * Oculta completamente a barra para quem não é admin com e-mail autorizado.
 */
add_action('after_setup_theme', 'ocultar_admin_bar_para_usuarios');
function ocultar_admin_bar_para_usuarios() {
    if (is_user_logged_in()) {
        $user = wp_get_current_user();
        if (!in_array('administrator', $user->roles) || strpos($user->user_email, '@tribo.uday.com.br') === false) {
            show_admin_bar(false); // Oculta no painel também
        }
    } else {
        show_admin_bar(false);
    }
}

/**
 * Remove o logo da tela de login.
 */
add_action('login_head', 'remover_logo_login_wordpress');
function remover_logo_login_wordpress() {
    echo '<style type="text/css">
        .login h1 a {
            display: none !important;
        }
    </style>';
}

/**
 * Desativa atualizações automáticas e notificações.
 */
add_filter('auto_update_plugin', '__return_false');
add_filter('auto_update_theme', '__return_false');
add_filter('auto_update_core', '__return_false');

// Remove notificações de atualizações na área administrativa
remove_action('admin_notices', 'update_nag', 3);

// Desativa verificação de atualizações de plugins
remove_action('load-update.php', 'wp_update_plugins');
add_filter('site_transient_update_plugins', function($value) {
    return null;
});

// Desativa verificação de atualizações de temas
remove_action('load-update.php', 'wp_update_themes');
add_filter('site_transient_update_themes', function($value) {
    return null;
});
